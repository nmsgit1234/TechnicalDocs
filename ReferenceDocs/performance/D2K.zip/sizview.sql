-- Sizview.sql 
-- Sizing package for use with Designer/2000
-- Author: Jeff Stander

col col_datatype format a10
col app format a5 trunc
col table_name format a30 trunc
col app_name format a18 trunc
col ver format 999
col tab format a30 trunc
col con format a30 trunc
col col format a30 trunc
col colformat format a4 trunc
col vol format 999999 trunc
col tab_name format a30 trunc
col sto_name format a30 trunc
col col_name format a30
col tablespace like sto_name
col index_name format a30
col ts_name format a30

create or replace package szutl as 
	function crl( col_id in number ) return number;
        PRAGMA RESTRICT_REFERENCES(CRL,WNDS,WNPS);
        function init_vol_perc( col_id in number ) return number;
        PRAGMA RESTRICT_REFERENCES(INIT_VOL_PERC,WNDS,WNPS);
        function final_vol_perc( col_id in number ) return number;
        PRAGMA RESTRICT_REFERENCES(FINAL_VOL_PERC,WNDS,WNPS);
        function init_vol( col_id in number ) return number;
        PRAGMA RESTRICT_REFERENCES(INIT_VOL,WNDS,WNPS);
        function final_vol( col_id in number ) return number;
        PRAGMA RESTRICT_REFERENCES(FINAL_VOL,WNDS,WNPS);
end szutl;
/

create or replace package body szutl as 
function crl( col_id in number ) return number is
   len number;
begin
select
decode(cols.el_format,
    'DATE',7,
    'VARCHAR',ceil(nvl(cols.el_av_len,cols.el_max_len)),
    'VARCHAR2',ceil(nvl(cols.el_av_len,cols.el_max_len)),
    'CHAR',cols.el_max_len,
    'NUMBER',ceil((cols.el_max_len/2)+1),cols.el_max_len )
into len from sdd_elements cols
where cols.el_id = col_id;
return len;
end;

function init_vol_perc( col_id in number ) return number is
    len number;
begin
select
       decode(col.el_init_perc_used,null,
          decode(col.el_max_perc_used,null,
             decode(col.el_opt,'NOT NULL',100,50),
             col.el_max_perc_used),
          col.el_init_perc_used) 
into len from sdd_elements col
where col.el_id = col_id;
return len;
end;

function final_vol_perc( col_id in number ) return number is
    len number;
begin
select
       decode(col.el_max_perc_used,null,
          decode(col.el_init_perc_used,null,
             decode(col.el_opt,'NOT NULL',100,50),
             col.el_init_perc_used),
          col.el_max_perc_used)
into len from sdd_elements col
where col.el_id = col_id;
return len;
end;

function init_vol( col_id in number ) return number is
    len number;
begin
select
    decode(col.el_format,
    'DATE',7,
    'VARCHAR',ceil(nvl(col.el_av_len,col.el_max_len)),
    'VARCHAR2',ceil(nvl(col.el_av_len,col.el_max_len)),
    'CHAR',col.el_max_len,
    'NUMBER',ceil((col.el_max_len/2)+1),col.el_max_len ) *
    decode(col.el_init_perc_used,null,
          decode(col.el_max_perc_used,null,
             decode(col.el_opt,'NOT NULL',100,50),
             col.el_max_perc_used),
          col.el_init_perc_used) / 100
into len from sdd_elements col
where col.el_id = col_id;
return len;
end;

function final_vol( col_id in number ) return number is
    len number;
begin
select
     decode(col.el_format,
    'DATE',7,
    'VARCHAR',ceil(nvl(col.el_av_len,col.el_max_len)),
    'VARCHAR2',ceil(nvl(col.el_av_len,col.el_max_len)),
    'CHAR',col.el_max_len,
    'NUMBER',ceil((col.el_max_len/2)+1),col.el_max_len ) *
    decode(col.el_max_perc_used,null,
          decode(col.el_init_perc_used,null,
             decode(col.el_opt,'NOT NULL',100,50),
             col.el_init_perc_used),
          col.el_max_perc_used) / 100
into len from sdd_elements col
where col.el_id = col_id;
return len;
end;


end szutl;
/


prompt idx_pre_volumetrics 
CREATE OR REPLACE VIEW idx_pre_volumetrics
(  app_name
,  app_ver
,  tab_name
,  sto_name
,  index_name
,  idx_type
,  col
,  col_datatype
,  max_col_len
,  init_col_len
,  final_col_len
,  tab_max_rows
,  tab_init_rows
)
AS
select app.el_name app_name,
 app.el_version app_ver,
 tab.el_name tab_name,
 sto.el_name sto_name,
 con.el_name index_name,
 keys.el_occur_type idx_type,
 cols.el_name col ,
 cols.el_format col_datatype,
 decode(cols.el_format,'DATE',7,cols.el_max_len) max_col_len,
 szutl.init_vol_perc(cols.el_id)  * szutl.crl(cols.el_id) /100 init_col_len,
 szutl.final_vol_perc(cols.el_id) * szutl.crl(cols.el_id) /100 final_col_len,
 tab.el_max_vol tab_max_rows ,
 tab.el_init_vol tab_init_rows
 from
 sdd_elements tab,
 sdd_elements con,
 sdd_elements keys,
 sdd_elements cols,
 sdd_elements app,
 sdd_elements sto
 where con.el_within_id = tab.el_id
 and keys.el_3rd_within_id = con.el_id
 and con.el_4th_within_id=sto.el_id
 and keys.el_2nd_within_id = cols.el_id
 and tab.el_type_of = 'TAB'
 and tab.el_occur_type = 'TABLE'
 and tab.el_elem_owned_by = app.el_id
 and tab.el_status = 'Y'
 and (
     keys.el_occur_type='PRIMARY'
     or keys.el_occur_type='UNIQUE'
     )
 UNION
select app.el_name app_name,
app.el_version app_ver,
tab.el_name tab_name,
sto.el_name sto_name,
ind.el_name index_name,
'INDEX' idx_type,
cols.el_name col ,
cols.el_format col_datatype,
 decode(cols.el_format,'DATE',7,cols.el_max_len) max_col_len,
 szutl.init_vol_perc(cols.el_id)  * szutl.crl(cols.el_id) / 100 init_col_len,
 szutl.final_vol_perc(cols.el_id) * szutl.crl(cols.el_id) / 100 final_col_len,
tab.el_max_vol tab_max_rows ,
tab.el_init_vol tab_init_rows
from
sdd_elements tab,
sdd_elements ind,
sdd_elements sto,
sdd_elements cols,
sdd_elements app,
sdd_structure_elements indcols
where tab.el_type_of = 'TAB'
and tab.el_id = ind.el_within_id
and ind.el_2nd_within_id=sto.el_id
and tab.el_elem_owned_by = app.el_id
and ind.el_id = indcols.str_part_of
and tab.el_id = cols.el_within_id
and tab.el_status = 'Y'
and indcols.str_type_of = 'INDCOL'
and app.el_type_of='APP'
and cols.el_type_of='COL'
and cols.el_id=indcols.str_use_of
/


prompt idx_volumetrics 
create or replace view idx_volumetrics as
select app_name,
       app_ver,
       tab_name,
       index_name,
       sto_name ts_name,
       idx_type,
       tab_init_rows,
       tab_max_rows,
       2+6+count(*)+sum(init_col_len) init_index_entry_size,
       2+6+count(*)+sum(final_col_len) final_index_entry_size,
       2+6+count(*)+sum(max_col_len) max_index_entry_size
from idx_pre_volumetrics
group by app_name,app_ver,tab_name,index_name,sto_name,idx_type,tab_init_rows,tab_max_rows
/

prompt app_idx_vols 
create or replace view app_idx_vols as
select nvl(ts_name,'tablespace unassigned')  tablespace  ,
ceil(1.1* 1.1*sum(tab_init_rows*init_index_entry_size)/1024/1024) init_idx_MB,
ceil(1.1* 1.1*sum(tab_max_rows*final_index_entry_size)/1024/1024) final_idx_MB,
ceil(1.1*1.1*sum(tab_max_rows*max_index_entry_size)/1024/1024) max_idx_MB 
from idx_volumetrics
group by nvl(ts_name,'tablespace unassigned')
/

prompt app_idxtype_vols 
create or replace view app_idxtype_vols as
select nvl(ts_name,'tablespace unassigned')  tablespace  ,
idx_type,
ceil(1.1* 1.1*sum(tab_init_rows*init_index_entry_size)/1024/1024) init_idx_MB,
ceil(1.1* 1.1*sum(tab_max_rows*final_index_entry_size)/1024/1024) final_idx_MB,
ceil(1.1*1.1*sum(tab_max_rows*max_index_entry_size)/1024/1024) max_idx_MB 
from idx_volumetrics
group by nvl(ts_name,'tablespace unassigned'),idx_type
/

prompt mod_tables 
create or replace view mod_tables as
select  app.name app,
        m.id mod_id,
        m.name mod,
        m.short_name,
        tables.el_name tab ,
        m_t.select_flag,
        m_t.insert_flag,
        m_t.update_flag,
        m_t.delete_flag,
        m_t.remark    
from    ci_modules m,
        ci_module_table_usages m_t,
        sdd_elements tables ,
        ci_application_systems app
where   m.id=m_t.module_reference(+)
and     m_t.table_reference=tables.el_id(+)
and     m.application_system_owned_by=app.id
/

prompt pre_storage_volumetrics 
create or replace view pre_storage_volumetrics as
  select app.el_name app,
  tab.el_name "TABLE",
  tabspace.el_name "TABLESPACE",
  sto.el_name storage_name,
  tab.el_init_vol tab_init_rows,
  tab.el_max_vol tab_max_rows,
  sto.el_sd_dp_init init_ext,
  sto.el_sd_dp_inc  next_Ext,
  sto.el_sd_ip_inc pct_incr,
  sto.el_sd_ip_max max_ext,
  sto.el_sd_ip_init min_ext
from
        sdd_elements sto, 
        sdd_elements tab, 
        sdd_elements app,
        sdd_elements tabspace
where   tab.el_elem_owned_by = app.el_id  
and     tab.el_status='Y'
and     tab.el_2nd_within_id=tabspace.el_id(+)
and     tabspace.el_type_of='OTB'
and     sto.el_type_of = 'OSP'
and     tab.el_4th_within_id(+)=sto.el_id 
and     tab.el_type_of='TAB'
/

prompt storage_volumetrics 
create or replace view storage_volumetrics 
(
app,
tabspace,
objs,
init_space_MB,
next_space_MB
) as
select app,
tablespace,
count(*),
sum(init_ext+((min_ext-1)*next_ext))/1024/1024,sum(next_ext)/1024/1024
from pre_storage_volumetrics
group by app,tablespace
/


prompt pre_volumetrics 
create or replace view pre_volumetrics as
select app.el_name app_name,
       app.el_version ver,
       tab.el_name tab_name,
       sto.el_name ts_name,
       col.el_name col_name,
       tab.el_init_vol tab_init_rows,
       tab.el_max_vol tab_max_rows,
       nvl(tab.el_init_perc_used,10) tab_pct_free,
       tab.el_max_perc_used tab_pct_used,
       col.el_format col_datatype,
       col.el_max_len col_max_len,
       col.el_av_len col_avg_len,
       decode(col.el_init_perc_used,null,
          decode(col.el_max_perc_used,null,
             decode(col.el_opt,'NOT NULL',100,50),
             col.el_max_perc_used),
          col.el_init_perc_used) start_vol_perc,
       decode(col.el_max_perc_used,null,
          decode(col.el_init_perc_used,null,
             decode(col.el_opt,'NOT NULL',100,50),
             col.el_init_perc_used),
          col.el_max_perc_used) end_vol_perc
from   sdd_elements col,
       sdd_elements tab,
       sdd_elements app,
       sdd_elements sto
where  col.el_within_id = tab.el_id
and    tab.el_elem_owned_by = app.el_id
and    tab.el_status='Y'
and    tab.el_occur_type='TABLE'
and    tab.el_2nd_within_id=sto.el_id
and    col.el_type_of = 'COL'
and    col.el_col_vl_id is null
/

prompt volumetrics 
 create or replace view volumetrics
 (
 APP_NAME,
 APP_VER,
 TAB_NAME,
 TS_NAME,
 COLUMNS,
 INIT_RECORDS,
 MAX_RECORDS,
 TAB_PCT_FREE,
 TAB_PCT_USED,
 INIT_ROW_DATA,
 FINAL_ROW_DATA,
 MAX_ROW_DATA
 ) as
 select
 substr(app_name,1,18),
 ver,
 substr(tab_name,1,30),
 substr(ts_name,1,30),
 count(*) columns ,
 tab_init_rows init_records,
 tab_max_rows records,
 tab_pct_free,
 tab_pct_used,
  (5 + count(*) + ceil( sum(
       start_vol_perc * decode(col_datatype,'DATE',7,
        'VARCHAR',col_avg_len,
        'CHAR',col_max_len,
        'VARCHAR2',ceil(col_avg_len),
      ceil((col_max_len/2)+1))/100))) init_row_data,
  (5 + count(*) + ceil( sum(
       end_vol_perc * decode(col_datatype,'DATE',7,
        'VARCHAR',col_avg_len,
        'CHAR',col_max_len,
        'VARCHAR2',ceil(col_avg_len),
      ceil((col_max_len/2)+1))/100))) final_row_data,
  (5 + count(*) + sum(
       (decode(col_datatype,'DATE',7,
        col_max_len)))) max_row_data
 from pre_volumetrics
 group by app_name,ver,tab_name,ts_name,tab_max_rows,tab_init_rows,tab_pct_free,tab_pct_used
/

-- This view is for loading to the SIZTAB.TABLE_VOLUMES spreadsheet
prompt sz_tab
create or replace view sz_tab as
select
 app_name,
 APP_ver,
 TAB_NAME,
 TS_NAME,
 COLUMNS,
 INIT_RECORDS,
 MAX_RECORDS,
 INIT_ROW_DATA,
 FINAL_ROW_DATA,
 MAX_ROW_DATA,
 TAB_PCT_FREE
from
 volumetrics
/

-- This view is for loading to the SIZTAB.INDEX_VOLUMES spreadsheet
prompt sz_idx
create or replace view sz_idx as
select
 APP_NAME,
 APP_VER,
 TAB_NAME,
 TS_NAME,
 INDEX_NAME IDX_NAME,
 ' ' DUMMY_FIELD,
 IDX_TYPE,
 TAB_INIT_ROWS,
 TAB_MAX_ROWS,
 FINAL_INDEX_ENTRY_SIZE,
 MAX_INDEX_ENTRY_SIZE   
from
 idx_volumetrics
/

prompt app_tab_vols 
create or replace view app_tab_vols as
select nvl(ts_name,'tablespace unassigned')  tablespace  ,
ceil(sum(1.05*init_records*init_row_data)/1024/1024)  init_tab_MB ,
ceil(sum(1.05*max_records*final_row_data)/1024/1024) final_tab_MB ,
ceil(sum(1.05*max_records*max_row_data)/1024/1024)   max_tab_MB 
from volumetrics
group by nvl(ts_name,'tablespace unassigned') 
/


-- Search repository for views/tables without a tablespace specification
prompt no_ts_spec
create or replace view no_ts_spec as
select app.el_name app_name,
 app.el_version ver,
 tab.el_name table_name,
 con.el_name index_name,
 keys.el_occur_type el_type
 from
 sdd_elements tab,
 sdd_elements con,
 sdd_elements keys,
 sdd_elements app
 where con.el_within_id = tab.el_id
 and keys.el_3rd_within_id = con.el_id
 and con.el_4th_within_id is null
 and tab.el_type_of = 'TAB'
 and tab.el_occur_type = 'TABLE'
 and tab.el_elem_owned_by = app.el_id
 and tab.el_status = 'Y'
 and keys.el_occur_type='PRIMARY'
UNION
select app.el_name app_name,
app.el_version ver,
tab.el_name tab_name,
ind.el_name index_name,
'INDEX' idx_type
from
sdd_elements tab,
sdd_elements ind,
sdd_elements app
where tab.el_type_of = 'TAB'
and tab.el_id = ind.el_within_id
and ind.el_2nd_within_id is null
and tab.el_elem_owned_by = app.el_id
and tab.el_status = 'Y'
and app.el_type_of='APP'
and ind.el_type_of = 'IND'
UNION
select app.el_name app_name,
       app.el_version ver,
       tab.el_name tab_name,
       '',
       tab.el_occur_type
from   sdd_elements tab,
       sdd_elements app
where  tab.el_elem_owned_by = app.el_id
and    tab.el_status='Y'
and    tab.el_occur_type='TABLE'
and    tab.el_2nd_within_id is null
UNION
select app_name, app_ver, tab_name, ts_name, 'WRONG TABLESPACE'
from idx_volumetrics
where ts_name not like '%INDEXES'
UNION
select app_name, app_ver, tab_name, ts_name, 'WRONG TABLESPACE'
from volumetrics
where ts_name like '%INDEXES'
/

-- Provide list of Elements and Tablespaces
prompt show_ts
create or replace view SHOW_TS
(
APP_NAME,
APP_VER,
TABLE_NAME,
ITEM_NAME,
ITEM_TYPE,
TABLESPACE_NAME
)
 as
select
   APP_NAME,
   APP_VER,
   TAB_NAME,
   INDEX_NAME,
   IDX_TYPE,
   TS_NAME
from idx_volumetrics
UNION
select
   APP_NAME,
   APP_VER,
   TAB_NAME,
   '',
   'TABLE',
   TS_NAME
from volumetrics
/
