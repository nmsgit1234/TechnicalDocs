===========================
HBase: The Definitive Guide
===========================

This repository has all the code as used in the HBase book.

